
// FFmpeg worker for resizing/transcoding videos before upload/publish.
// Requires ffmpeg binary accessible via FFMPG_PATH env var.
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

async function transcode(inputPath, outputPath, preset = '1280:720') {
  return new Promise((resolve, reject) => {
    const ffmpeg = spawn(process.env.FFMPG_PATH || '/usr/bin/ffmpeg', [
      '-y',
      '-i', inputPath,
      '-vf', `scale=${preset}`,
      '-c:v', 'libx264',
      '-preset', 'fast',
      '-crf', '23',
      outputPath
    ]);
    ffmpeg.stderr.on('data', d => console.error(d.toString()));
    ffmpeg.on('close', code => code === 0 ? resolve(outputPath) : reject(new Error('ffmpeg failed')) );
  });
}

// Example usage: node ffmpeg-worker.js /tmp/input.mp4 /tmp/out.mp4
if (require.main === module) {
  const [,, inP, outP] = process.argv;
  if (!inP || !outP) return console.error('Usage: ffmpeg-worker.js <in> <out>');
  transcode(inP, outP).then(()=>console.log('done')).catch(e=>console.error(e));
}
