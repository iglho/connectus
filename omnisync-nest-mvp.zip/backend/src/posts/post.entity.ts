
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity('posts')
export class PostEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column('text', { nullable: true })
  caption: string;

  @Column('jsonb', { nullable: true })
  platforms: any;

  @Column('jsonb', { nullable: true })
  media: any;

  @Column({ default: 'draft' })
  status: string;

  @CreateDateColumn()
  createdAt: Date;

  @Column({ type: 'timestamptz', nullable: true })
  scheduleAt: Date;

  @Column({ type: 'timestamptz', nullable: true })
  publishedAt: Date;
}
