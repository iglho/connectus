
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PostEntity } from './post.entity';
import { Queue } from 'bullmq';
import IORedis from 'ioredis';

const connection = new IORedis({ host: process.env.REDIS_HOST || 'redis' });
const publishQueue = new Queue('publish', { connection });

@Injectable()
export class PostsService {
  constructor(@InjectRepository(PostEntity) private repo: Repository<PostEntity>) {}

  async create(data: any) {
    const p = this.repo.create(data);
    const saved = await this.repo.save(p);
    if (data.scheduleAt) {
      const delay = Math.max(new Date(data.scheduleAt).getTime() - Date.now(), 0);
      await publishQueue.add('publish-job', { postId: saved.id }, { delay });
      saved.status = 'scheduled';
    } else {
      await publishQueue.add('publish-job', { postId: saved.id });
      saved.status = 'queued';
    }
    return this.repo.save(saved);
  }

  findAll() { return this.repo.find(); }
}
