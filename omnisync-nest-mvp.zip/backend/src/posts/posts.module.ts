
import { Module } from '@nestjs/common';
import { PostsService } from './posts.service';
import { PostsController } from './posts.controller';
import { BullModule } from '@nestjs/bullmq';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PostEntity } from './post.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([PostEntity]),
    BullModule.registerQueue({ name: 'publish' })
  ],
  controllers: [PostsController],
  providers: [PostsService]
})
export class PostsModule {}
