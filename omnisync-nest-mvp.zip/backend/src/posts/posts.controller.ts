
import { Controller, Post, Body, Get, UploadedFiles, UseInterceptors } from '@nestjs/common';
import { FileFieldsInterceptor, FilesInterceptor } from '@nestjs/platform-express';
import { PostsService } from './posts.service';

@Controller('posts')
export class PostsController {
  constructor(private posts: PostsService) {}

  @Post('create')
  @UseInterceptors(FilesInterceptor('media'))
  async create(@UploadedFiles() files: any, @Body() body: any) {
    // files processing and S3 upload handled in S3Service (inject in real impl)
    const media = (files || []).map(f => ({ key: f.filename, original: f.originalname }));
    const data = { ...body, media, platforms: JSON.parse(body.platforms || '[]') };
    return this.posts.create(data);
  }

  @Get('list')
  findAll() { return this.posts.findAll(); }
}
