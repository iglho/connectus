
import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {
  constructor(private jwt: JwtService) {}

  // Demo login - in production wire to user DB and password hashing
  async login(email: string) {
    const payload = { sub: 'user-1', email, role: 'admin' };
    return { access_token: this.jwt.sign(payload) };
  }
}
