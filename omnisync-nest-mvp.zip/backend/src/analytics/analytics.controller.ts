
import { Controller, Get } from '@nestjs/common';

@Controller('analytics')
export class AnalyticsController {
  @Get('overview')
  overview() {
    return {
      totalFollowers: 84230,
      engagementChange7d: 12,
      topPosts: [{id:'p1', title:'Best Reel', platform:'instagram', likes:1200}]
    };
  }
}
