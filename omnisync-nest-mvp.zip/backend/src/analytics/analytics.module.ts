
import { Module, Controller, Get } from '@nestjs/common';

@Module({})
export class AnalyticsModule {}
