
import { Injectable, Logger } from '@nestjs/common';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class S3Service {
  private client: S3Client;
  private bucket: string;
  private logger = new Logger('S3Service');

  constructor(private config: ConfigService) {
    this.client = new S3Client({ region: config.get('AWS_REGION') });
    this.bucket = config.get('S3_BUCKET');
  }

  async uploadBuffer(key: string, buffer: Buffer, contentType: string) {
    const cmd = new PutObjectCommand({
      Bucket: this.bucket,
      Key: key,
      Body: buffer,
      ContentType: contentType
    });
    const res = await this.client.send(cmd);
    this.logger.log(`Uploaded ${key} to S3`);
    return { key, res };
  }
}
