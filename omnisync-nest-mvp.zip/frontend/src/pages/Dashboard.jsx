
import React, {useEffect, useState} from 'react'
import axios from 'axios'

export default function Dashboard(){
  const [stats, setStats] = useState(null)
  useEffect(()=>{ axios.get('/api/analytics/overview').then(r=>setStats(r.data)) },[])
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Dashboard</h1>
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2 bg-white p-4 rounded shadow">
          <div className="text-4xl">{stats ? stats.totalFollowers : '...'}</div>
          <div>Engagement 7d: {stats ? stats.engagementChange7d + '%' : '...'}</div>
        </div>
        <aside className="bg-white p-4 rounded shadow">Unified Inbox (placeholder)</aside>
      </div>
    </div>
  )
}
