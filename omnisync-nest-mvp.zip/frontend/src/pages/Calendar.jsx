
import React, {useEffect, useState} from 'react'
import axios from 'axios'
export default function Calendar(){
  const [posts,setPosts]=useState([])
  useEffect(()=>{ axios.get('/api/posts/list').then(r=>setPosts(r.data)) },[])
  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-xl mb-4">Calendar</h2>
      <ul>{posts.map(p=><li key={p.id}>{p.scheduleAt?`Scheduled: ${new Date(p.scheduleAt).toLocaleString()}`:'Published'} - {p.caption?.slice(0,60)}</li>)}</ul>
    </div>
  )
}
