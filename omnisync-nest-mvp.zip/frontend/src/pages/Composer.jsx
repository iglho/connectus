
import React, {useState} from 'react'
import axios from 'axios'

export default function Composer(){
  const [caption,setCaption]=useState('')
  const [platforms,setPlatforms]=useState([])
  const [files,setFiles]=useState([])
  const toggle = p => setPlatforms(prev=> prev.includes(p)?prev.filter(x=>x!==p):[...prev,p])
  const submit = async ()=> {
    const fd = new FormData()
    fd.append('caption', caption)
    fd.append('platforms', JSON.stringify(platforms))
    for(const f of files) fd.append('media', f)
    const res = await axios.post('/api/posts/create', fd)
    alert('Created ' + res.data.id)
  }
  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-xl mb-4">Composer</h2>
      <div className="mb-3">Platforms:
        {['instagram','facebook','youtube','tiktok','x','linkedin'].map(p=>(
          <button key={p} onClick={()=>toggle(p)} className={`ml-2 px-2 py-1 rounded ${platforms.includes(p)?'bg-blue-600 text-white':'bg-gray-200'}`}>{p}</button>
        ))}
      </div>
      <textarea value={caption} onChange={e=>setCaption(e.target.value)} className="w-full border p-2 mb-3" placeholder="Write your post..." />
      <input type="file" multiple onChange={e=>setFiles(Array.from(e.target.files))} />
      <div className="mt-4">
        <button onClick={submit} className="px-4 py-2 bg-green-600 text-white rounded">Save / Publish</button>
      </div>
    </div>
  )
}
