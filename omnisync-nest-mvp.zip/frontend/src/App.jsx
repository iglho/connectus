
import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import Composer from './pages/Composer'
import Calendar from './pages/Calendar'

export default function App(){
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow p-4 flex justify-between items-center">
        <div className="text-xl font-bold">OmniSync</div>
        <nav className="space-x-4">
          <Link to="/composer" className="btn">Composer</Link>
          <Link to="/calendar" className="btn">Calendar</Link>
        </nav>
      </header>
      <main className="p-6">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/composer" element={<Composer />} />
          <Route path="/calendar" element={<Calendar />} />
        </Routes>
      </main>
    </div>
  )
}
