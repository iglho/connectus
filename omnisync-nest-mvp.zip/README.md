
# OmniSync MVP v1.0 (NestJS + React)
This repo is a production-minded scaffold for OmniSync MVP:
- Backend: NestJS (TypeScript) with modular structure, S3 service, FFmpeg worker, OAuth adapter placeholders.
- Frontend: React + Vite + Tailwind with pixel-ready components and routes (Dashboard, Composer, Calendar).
- Background queue: BullMQ + Redis.
- Database: PostgreSQL (TypeORM).
- Docker-compose for local dev.

## Quickstart (dev)
1. Create `.env` files for backend and frontend (see `.env.example`).
2. Ensure Docker is running.
3. From repo root: `docker-compose up --build`
4. Backend: http://localhost:4000, Frontend: http://localhost:3000

## Notes
- OAuth integrations require app credentials (set ENV vars). Strategies are ready as adapters in `backend/src/auth`.
- S3: set AWS_* env vars. `S3Service` uses `@aws-sdk/client-s3`.
- FFmpeg worker is provided as `worker/ffmpeg-worker.js` (requires ffmpeg binary in container).
- This scaffold is intended as a starting point; fill in real OAuth flow and platform publish adapters.
